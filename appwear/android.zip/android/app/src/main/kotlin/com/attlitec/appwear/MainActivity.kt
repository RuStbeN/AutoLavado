package com.attlitec.appwear

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
